from flask import Flask
app = Flask (__name__)

@app.route('/entero/<int:valor>') #lo q va a ir en la url#
def entero (valor):
    return "Hello %d" % valor #d de digito#

@app.route('/flotante/<float:valor>') 
def flotante (valor):
    return "Hello %d" % valor 

if __name__ == '__main__':
    app.run(debug = True)
