function saluda()(
	alert ("Hola"):
)